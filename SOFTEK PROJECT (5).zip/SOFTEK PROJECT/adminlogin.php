<?php
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$email = $_POST['email'];
$password = $_POST['password'];

// Sanitize POST data
$email = stripslashes($email);
$email = addslashes($email);
$password = stripslashes($password);
$password = addslashes($password);

// Prepare and execute SQL statement
$stmt = $conn->prepare("SELECT email FROM adminlogin WHERE email = ? AND password = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $_SESSION["email"] = $email; // Set session variable for admin
    $_SESSION["role"] = "admin"; // Set role for admin
    echo "Login successful!";
} else {
    echo "Wrong Username or Password";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
