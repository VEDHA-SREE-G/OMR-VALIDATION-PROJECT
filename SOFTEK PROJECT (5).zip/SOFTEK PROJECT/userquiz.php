<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve POST data
$testid = $_POST['testid']; 
$userid = $_POST['userid']; 

// Prepare the DELETE statement
$delete_stmt = $conn->prepare("DELETE FROM userquiz WHERE testid = ? AND userid = ?");
// Bind parameters
$delete_stmt->bind_param("ii", $testid, $userid);

// Execute DELETE statement
if (!$delete_stmt->execute()) {
    die("Error deleting existing rows: " . $delete_stmt->error);
}

// Prepare the INSERT statement
$insert_stmt = $conn->prepare("INSERT INTO userquiz (testid, userid, qno, option) VALUES (?, ?, ?, ?)");
// Check if prepare failed
if (!$insert_stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters
$insert_stmt->bind_param("iiis", $testid, $userid, $question_id, $selected_option);

// Iterate over POST data
foreach ($_POST as $key => $value) {
    // Expecting keys to be in the format 'qX' where X is the question number
    if (preg_match('/^q(\d+)$/', $key, $matches)) {
        $question_id = intval($matches[1]); // Extract the question number as an integer
        $selected_option = $value;

        // Ensure the selected option is a single character
        if (strlen($selected_option) == 1) {
            // Execute the prepared statement
            if (!$insert_stmt->execute()) {
                echo "Error: " . $insert_stmt->error;
            }
        } else {
            echo "Invalid option value: $selected_option";
        }
    }
}

// Close statements and connection
$delete_stmt->close();
$insert_stmt->close();
$conn->close();
?>
