<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <style>
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
            margin-top: 60px; /* Add margin to prevent overlap with fixed header */
        }
        .landing-content {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .landing-content h1 {
            font-size: 36px;
            color: #c71585;
            margin: 0 0 20px;
        }
        .landing-content p {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
        }
        .formatting-rules {
            text-align: left;
            font-size: 16px;
            color: #444;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .formatting-rules strong {
            display: block;
            font-size: 20px;
            color: #c71585;
            margin-bottom: 10px;
        }
        .formatting-rules ol {
            margin: 0;
            padding-left: 20px;
        }
        .button-wrapper {
            display: flex;
            justify-content: center;
            gap: 20px; /* Add space between buttons */
        }
        .create-button, .remove-button {
            text-decoration: none;
            background-color: #c71585;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            border: none;
            display: inline-block;
        }
        .create-button:hover, .remove-button:hover {
            background-color: #a3006f;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="landing-content">
            <h1>Welcome to Our Service</h1>
            <p>Start building your project from scratch or explore our features.</p>
            <div class="formatting-rules">
                <strong>Formatting Rules for Questions and Options</strong>
                <ol>
                    <li>The question should start with a capital "Q" followed by a number and a dot (e.g., Q1., Q2., etc.).</li>
                    <li>The question should end with a question mark (e.g., ?).</li>
                    <li>The options should start with a capital letter, followed by a number and a dot (e.g., A1., B1., C1., D1., etc.).</li>
                </ol>
                <div class="button-wrapper">
                    <a href="pdfextract.php" class="create-button">Create from Scratch</a>
                    <a href="remove.php" class="remove-button">Remove Quiz</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>