
<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <style>
      .header {
            display: flex;
            justify-content: flex-end; /* Align items to the right */
            align-items: center;
            background-color: #c71585;
            color: #ffffff;
            padding: 10px 20px;
            width: 100%; /* Ensure header spans the full width */
            box-sizing: border-box; /* Include padding in width calculation */
            position: fixed; /* Fix the header at the top */
            top: 0;
            left: 0;
            z-index: 1000; /* Ensure it stays on top */
            height: 60px;
        }

        .header-content {
            display: flex;
            align-items: center;
        }

        .email {
            margin-right: 20px; /* Space between email and sign-out button */
            font-size: 16px;
            font-family: Arial, sans-serif;
        }

        .logout-btn {
            background-color: #ffffff;
            color: #c71585;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
        }

        .logout-btn:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
        // Display email based on user role
        if (isset($_SESSION['user_email'])) {
            echo '<div class="email">' . htmlspecialchars($_SESSION['user_email']) . '</div>';
        } else {
            echo '<div class="email">Not logged in</div>';
        }
        ?>
        <a href="logout.php" class="logout-btn">Sign Out</a>
    </div>
</body>
</html>

