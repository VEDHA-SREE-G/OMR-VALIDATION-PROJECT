<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all tests
$sql = "SELECT testid, testname, hours, minutes, seconds FROM test";
$result = $conn->query($sql);

$tests = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tests[] = $row;
    }
}

// Return the tests as a JSON response
header('Content-Type: application/json');
echo json_encode($tests);

// Close connection
$conn->close();
?>