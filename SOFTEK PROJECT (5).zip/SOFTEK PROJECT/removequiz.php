<?php
// removequiz.php
$testid = $_GET['testid'] ?? '';

if ($testid) {
    // Connect to your database
    $pdo = new PDO('mysql:host=localhost;dbname=omrsheet', 'root', '');

    // Prepare and execute delete statement
    $stmt = $pdo->prepare('DELETE FROM test WHERE testid = ?');
    $stmt->execute([$testid]);

    if ($stmt->rowCount() > 0) {
        http_response_code(200); // OK
    } else {
        http_response_code(404); // Not Found
    }
} else {
    http_response_code(400); // Bad Request
}
?>