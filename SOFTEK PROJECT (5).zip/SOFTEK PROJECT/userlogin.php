<?php
session_start();
header('Content-Type: application/json');

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Get POST data
$email = $_POST['email'];
$password = $_POST['password'];

// Sanitize POST data
$email = stripslashes($email);
$email = addslashes($email);
$password = stripslashes($password);
$password = addslashes($password);

// Prepare and execute SQL statement
$stmt = $conn->prepare("SELECT userid, name FROM user WHERE user_email = ? AND password = ?");
if (!$stmt) {
    die(json_encode(["error" => "Prepare failed: " . $conn->error]));
}
$stmt->bind_param("ss", $email, $password);

$response = array();

if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $response["userid"] = $row["userid"];
        $response["name"] = $row["name"];
        $_SESSION['user_email'] = $email; // Set session variable for user email

        echo json_encode($response); // Return the response with user data
    } else {
        $response["error"] = "Wrong Username or Password";
        echo json_encode($response); // Return error message
    }
} else {
    $response["error"] = "Execution failed: " . $stmt->error;
    echo json_encode($response); // Return error message
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
