<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the testid from the query parameter
$testid = intval($_GET['testid']);

if (!$testid) {
    die("Invalid test ID.");
}

// Query to fetch hours, minutes, and seconds from the 'test' table
$sql = "SELECT hours, minutes, seconds FROM test WHERE testid = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $testid);  // Use the provided testid
$stmt->execute();

$result = $stmt->get_result();
if ($result === false) {
    die("Error executing query: " . $stmt->error);
}

if ($result->num_rows > 0) {
    // Fetch the row
    $row = $result->fetch_assoc();
    
    // Return the time in seconds
    $totalSeconds = ($row['hours'] * 3600) + ($row['minutes'] * 60) + $row['seconds'];
    echo $totalSeconds;
} else {
    echo "No time found for test ID: $testid";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
