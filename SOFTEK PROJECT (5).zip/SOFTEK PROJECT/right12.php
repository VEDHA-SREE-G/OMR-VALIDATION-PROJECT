<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the testid from the query parameter
$testid = intval($_GET['testid']);

// Initialize variables
$pdfId = null;
$testName = null;
$pdfContent = null;

// Step 1: Retrieve the testname and pdfId associated with the testid
$testStmt = $conn->prepare("SELECT testname, pdfId FROM test WHERE testid = ?");
$testStmt->bind_param("i", $testid);
$testStmt->execute();
$testStmt->bind_result($testName, $pdfId);
$testStmt->fetch();
$testStmt->close();

// Debugging: Print the testName and pdfId
error_log("testName: " . $testName);
error_log("pdfId: " . $pdfId);

// Step 2: Retrieve the content from pdf_contents using the pdfId
if ($pdfId) {
    $pdfStmt = $conn->prepare("SELECT content FROM pdf_contents WHERE id = ?");
    $pdfStmt->bind_param("i", $pdfId);
    $pdfStmt->execute();
    $pdfStmt->bind_result($pdfContent);
    $pdfStmt->fetch();
    $pdfStmt->close();
}

// Debugging: Print the pdfContent
error_log("pdfContent: " . $pdfContent);

// Handle case where pdfContent is null
if ($pdfContent === null) {
    $pdfContent = "No content available.";
}

// Return the testname and PDF content as a JSON response
header('Content-Type: application/json');
echo json_encode([
    'test' => [
        'testname' => $testName
    ],
    'pdf_content' => $pdfContent
]);

// Close connection
$conn->close();
?>
