<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start transaction
$conn->begin_transaction();

try {
    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO pdf_contents (content) VALUES (?)");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Get POST data
    $pdfText = isset($_POST["pdfText"]) ? $_POST["pdfText"] : '';

    // Bind parameters
    $stmt->bind_param("s", $pdfText);

    // Execute the statement
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    // Get the ID of the newly inserted PDF content
    $pdfId = $stmt->insert_id;

    // Commit transaction
    $conn->commit();

    // Return the ID
    echo $pdfId;
} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>