<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['testid'])) {
    $testid = $_POST['testid'];
} else {
    die("Test ID is not set.");
} 

// Prepare statement
$stmt = $conn->prepare("INSERT INTO quiz (testid, qno, option) VALUES (?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind parameters
$stmt->bind_param("iis", $testid, $question_id, $selected_option);

// Iterate over POST data
foreach ($_POST as $key => $value) {
    // Check if the key format is 'qX'
    if (preg_match('/^q(\d+)$/', $key, $matches)) {
        $question_id = intval($matches[1]); // Extract the question number as an integer
        
        // Increment question_id by 1 to correct for the starting index issue
        $question_id++;

        $selected_option = $value;

        // Ensure the selected option is a single character
        if (strlen($selected_option) == 1) {
            // Execute the prepared statement
            if (!$stmt->execute()) {
                echo "Error: " . $stmt->error;
            }
        } else {
            echo "Invalid option value: $selected_option";
        }
    }
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
