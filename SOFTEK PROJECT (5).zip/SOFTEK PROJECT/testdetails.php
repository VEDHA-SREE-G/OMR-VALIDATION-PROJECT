
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            text-align: center;
        }
        .card h2 {
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input[type="text"], .form-group input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-group input[type="number"] {
            width: calc(100% - 20px);
            display: inline-block;
            box-sizing: border-box;
        }
        .form-group .input-row {
            margin-bottom: 10px;
        }
        .form-group input[type="number"]:nth-child(1) {
            margin-bottom: 10px;
        }
        .btn {
            background-color: #8806ce;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #7005a9;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>Enter Test Details</h2>
        <form id="testDetailsForm">
            <div class="form-group">
                <label for="testName">Test Name:</label>
                <input type="text" id="testName" name="testName" required>
            </div>
            <div class="form-group">
                <label>Test Duration:</label>
                <div class="input-row">
                    <input type="number" id="testHours" name="testHours" placeholder="Hours" min="0" required>
                </div>
                <div class="input-row">
                    <input type="number" id="testMinutes" name="testMinutes" placeholder="Minutes" min="0" max="59" required>
                </div>
                <div class="input-row">
                    <input type="number" id="testSeconds" name="testSeconds" placeholder="Seconds" min="0" max="59" required>
                </div>
            </div>
            <button type="button" class="btn" onclick="submitForm()">Generate Questions</button>
        </form>
    </div>

    <script>

        // Function to handle form submission
        function submitForm() {
            const form = document.getElementById('testDetailsForm');
            const formData = new FormData(form);

            // Get pdfId from the URL
            const urlParams = new URLSearchParams(window.location.search);
            const pdfId = urlParams.get('pdfId'); // Get the pdfId parameter from URL
            if (pdfId) {
                formData.append('pdfId', pdfId); // Append pdfId to FormData
            }

            const hours = formData.get('testHours');
            const minutes = formData.get('testMinutes');
            const seconds = formData.get('testSeconds');

            const duration = (parseInt(hours) || 0) * 3600 + (parseInt(minutes) || 0) * 60 + (parseInt(seconds) || 0);

            fetch('test.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(testid => {
                console.log('Received testid:', testid); // Debugging statement

                if (testid) {
                    localStorage.setItem('testDuration', duration); // Store duration in localStorage
                    
                    // Pass testid in URL
                    window.location.href = `right10.php?testid=${testid}&pdfId=${pdfId}`; 
                } else {
                    console.error('Failed to get testid');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
    </script>
</body>
</html>