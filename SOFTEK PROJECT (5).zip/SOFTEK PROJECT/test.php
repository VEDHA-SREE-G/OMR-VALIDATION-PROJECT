<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start transaction
$conn->begin_transaction();

try {
    // Get POST data
    $testName = $_POST["testName"];
    $testHours = $_POST["testHours"];
    $testMinutes = $_POST["testMinutes"];
    $testSeconds = $_POST["testSeconds"];
    
    // Get pdfId from POST data
    $pdfId = isset($_POST["pdfId"]) ? (int)$_POST["pdfId"] : null;

    // Debugging: output pdfId and other POST data
    error_log("pdfId: " . $pdfId);

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO test (testname, hours, minutes, seconds, pdfId) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("siiii", $testName, $testHours, $testMinutes, $testSeconds, $pdfId);

    // Execute the statement
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    // Get the ID of the newly inserted test
    $testId = $stmt->insert_id;

    // Commit transaction
    $conn->commit();
    
    echo $testId;
} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>