<?php
$servername = "localhost";
$username = "root"; // Update with your MySQL username
$password = ""; // Update with your MySQL password
$dbname = "omrsheet"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the latest PDF content
$sql = "SELECT content FROM pdf_contents ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

$content = "";
if ($result->num_rows > 0) {
    // Output data of the latest row
    $row = $result->fetch_assoc();
    $content = $row['content'];
}

// Close connection
$conn->close();

// Return content as JSON
echo json_encode(array("content" => $content));
?>