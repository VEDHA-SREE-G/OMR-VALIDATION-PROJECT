<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>OMR VALIDATION</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
    <style>
        .container {
            display: flex;
            height: 100vh; /* 100% of the viewport height */
        }
        .left {
            flex: 1; /* Takes up 50% of the container */
            background-color: #f0f0f0; /* Light gray background */
            padding: 20px;
            padding: 20px;
            overflow-y: auto; /* Scroll if content overflows */
            margin-top: 60px;
        }
        .right {
            flex: 1; /* Takes up 50% of the container */
            background-color: #e0e0e0; /* Lighter gray background */
            padding: 20px;
            margin-top:60px;
            overflow-y: auto;
        }
        .navbar {
            display: flex; /* Use flexbox */
            justify-content: space-between; /* Distribute items evenly */
            align-items: center; /* Center items vertically */
            width: 100%; /* Full width */
            padding: 10px; /* Add some padding */
            background-color: #f0f0f0; /* Light gray background */
        }
        .navbar i {
            font-size: 24px; /* Adjust icon size */
            color: #333; /* Set icon color */
            cursor: pointer; /* Change cursor to pointer */
        }
        .circle-button {
            display: inline-block;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #c71585;
            text-align: center;
            font-size: 16px;
            margin-right: 10px;
            transition: background-color 0.3s; /* Add transition effect */
        }
        .circle-button:hover {
            background-color: #8806ce; /* Change background color on hover */
        }
        .btn {
            background-color: #c71585;
        }
        .btn:hover {
            background-color: #8806ce;
        }
        .question-list {
            list-style-type: none;
        }
        .question-list li {
            margin-bottom: 20px;
            display: none; /* Hide all questions initially */
        }
        .question-list li.active {
            display: block; /* Show only active question */
        }
        .answer {
            font-size: 1.2rem;
        }
        .btn-group {
            margin-top: 20px;
            text-align: center;
        }
        .omr-question {
            margin-bottom: 20px;
        }
        .options-container {
            display: flex;
            align-items: center; /* Center vertically */
            margin-top: 2px;
        }
        .question-number {
            margin-top: -15px;
            margin-right: 20px; /* Space between question number and options */
            font-weight: bold; /* Make question number bold */
        }
        .option {
            margin-right: 5px; /* Space between options */
            display: flex;
            align-items: center;
            position: relative;
        }
        .option input[type="radio"] {
            display: none; /* Hide default radio button */
        }
        .option label {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 30px; /* Circle diameter */
            height: 30px; /* Circle diameter */
            border-radius: 50%;
            border: 2px solid #333; /* Border color */
            background-color: #fff; /* Background color */
            font-size: 16px;
            cursor: pointer;
            margin-right: 5px;
            transition: background-color 0.3s, border-color 0.3s; /* Transition effects */
        }
        .option input[type="radio"]:checked + label {
            background-color: black; /* Background color when selected */
            border-color: black; /* Border color when selected */
            color: black; /* Text color when selected */
        }
        

    </style>
</head>
<body>
    
        <div class="container">
            <div class="left">
                <h2>QUESTION & ANSWERS</h2>
                <ul class="question-list" id="question-list">
                    <!-- Questions will be inserted here dynamically -->
                </ul>
                <div class="btn-group">
                    <button id="prevBtn" class="btn" onclick="prevQuestion()">Previous</button>
                    <button id="nextBtn" class="btn" onclick="nextQuestion()">Next</button>
                </div>
            </div>
            <div class="right">
                <h2>OMR SHEET</h2>
                <div class="omr-sheet">
                    <form method="post" action="adminquiz.php" id="omr-form">
                        <input type="hidden" name="testid" value="<?php echo htmlspecialchars($_GET['testid']); ?>">

                        <div id="omr-questions-container">
                            <!-- OMR questions will be inserted here dynamically -->
                        </div>
                        <button id="download" type="button" class="btn">
                            <svg width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mysvg">
                                <g id="SVGRepo_iconCarrier">
                                    <path id="Vector" d="M6 21H18M12 3V17M12 17L17 12M12 17L7 12" stroke="#f1f1f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </g>
                            </svg>
                            <span class="texto">Download</span>
                        </button>
                        <input type="submit" value="Submit" id="submit" class="btn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
     
      // Fetch testid from URL query parameters
      const urlParams = new URLSearchParams(window.location.search);
        const testid = urlParams.get('testid');
    
        // Fetch and display the time
        

        fetch('get_user_email.php')
            .then(response => response.text())
            .then(email => {
                document.getElementById('userEmail').textContent = email;
            })
            .catch(error => console.error('Error fetching email:', error));




        var currentQuestionIndex = 0;
        var totalQuestions = 0;

        function createQuestionElement(question, answers) {
            var li = document.createElement('li');
            li.className = 'question';
            if (currentQuestionIndex === 0) li.classList.add('active');
            
            var questionText = document.createElement('div');
            questionText.className = 'answer';
            questionText.innerText = question;
            
            var answerList = document.createElement('div');
            answerList.className = 'answers';
            answers.forEach((answer, i) => {
                var option = document.createElement('div');
                option.className = 'option';
                // Extract only the letter options (A, B, C, D) and their text
                var letter = String.fromCharCode(65 + i); // 'A' for 0, 'B' for 1, etc.
                var cleanAnswer = answer.replace(/^[A-Z]\d*\.\s*/, ''); // Remove any leading letter, digits, and periods
                option.innerText = letter + ') ' + cleanAnswer;
                answerList.appendChild(option);
            });

            li.appendChild(questionText);
            li.appendChild(answerList);

            return li;
        }

        function createOMRQuestionElement(index) {
    var div = document.createElement('div');
    div.className = 'omr-question';
    div.innerHTML = `
        <div class="options-container">
            <div class="question-number">Q${index + 1}.</div>
            <div class="option">
                <input type="radio" id="q${index}_option1" name="q${index}" value="A">
                <label for="q${index}_option1">A</label>
            </div>
            <div class="option">
                <input type="radio" id="q${index}_option2" name="q${index}" value="B">
                <label for="q${index}_option2">B</label>
            </div>
            <div class="option">
                <input type="radio" id="q${index}_option3" name="q${index}" value="C">
                <label for="q${index}_option3">C</label>
            </div>
            <div class="option">
                <input type="radio" id="q${index}_option4" name="q${index}" value="D">
                <label for="q${index}_option4">D</label>
            </div>
        </div>
    `;
    return div;
}

        function prevQuestion() {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                showQuestion(currentQuestionIndex);
                updateButtons();
            }
        }

        function nextQuestion() {
            if (currentQuestionIndex < totalQuestions - 1) {
                currentQuestionIndex++;
                showQuestion(currentQuestionIndex);
                updateButtons();
            }
        }

        function showQuestion(index) {
            var questions = document.getElementsByClassName("question");
            for (var i = 0; i < questions.length; i++) {
                questions[i].classList.remove("active");
            }
            questions[index].classList.add("active");
        }

        function updateButtons() {
            document.getElementById("prevBtn").disabled = (currentQuestionIndex === 0);
            document.getElementById("nextBtn").disabled = (currentQuestionIndex === totalQuestions - 1);
        }

        function submitAnswers() {
            const docDefinition = {
                content: [],
                pageMargins: [0, 0, 0, 0] // No margins
            };

            const questions = document.querySelectorAll('.omr-sheet .omr-question');
            questions.forEach((question, index) => {
                const selectedOption = question.querySelector('input[type="radio"]:checked');
                if (selectedOption) {
                    const questionNumber = question.querySelector('.question-number').textContent.trim();
                    const selectedValue = selectedOption.value;
                    const options = ['A', 'B', 'C', 'D'];

                    const canvas = document.createElement('canvas');
                    canvas.width = 400;
                    canvas.height = 50;
                    const ctx = canvas.getContext('2d');

                    // Draw question number
                    ctx.font = '16px Arial';
                    ctx.fillText(questionNumber, 10, 30);

                    // Draw options
                    const optionWidth = 60;
                    options.forEach((option, i) => {
                        const x = 100 + optionWidth * i;
                        const y = 30;
                        ctx.beginPath();
                        ctx.arc(x + 10, y - 5, 10, 0, Math.PI * 2); // Draw black circle
                        ctx.stroke();

                        if (option === selectedValue) {
                            ctx.fillStyle = '#000000'; // Black color for selected option
                            ctx.fill();
                        } else {
                            ctx.fillStyle = 'white'; // White color for other options
                        }
                        ctx.fill();
                        ctx.fillStyle = 'black';
                        ctx.fillText(option, x + 5, y);
                    });

                    // Convert canvas to data URL
                    const dataUrl = canvas.toDataURL('image/png');

                    // Add image to PDF content
                    docDefinition.content.push({ image: dataUrl, width: 400 });
                }
            });

            // Generate PDF and download
            pdfMake.createPdf(docDefinition).download('omr_sheet.pdf');
        }
        

        window.onload = function () {
            document.getElementById("download").addEventListener("click", submitAnswers);

            // Fetch content from the server
            fetch('fetch_pdf_content.php')
                .then(response => response.json())
                .then(data => {
                    var questionsData = data.content.split("Q");
                    totalQuestions = questionsData.length - 1;
                    var questionList = document.getElementById("question-list");
                    var omrQuestionsContainer = document.getElementById("omr-questions-container");

                    for (var i = 1; i <= totalQuestions; i++) {
                        var questionAndAnswers = questionsData[i].split(/(?=[ABCD]\d+\.)/);
                        var question = questionAndAnswers[0].trim();
                        var answers = questionAndAnswers.slice(1).map(answer => answer.trim());
                        var questionElement = createQuestionElement(question, answers);
                        questionList.appendChild(questionElement);

                        var omrQuestionElement = createOMRQuestionElement(i - 1);
                        omrQuestionsContainer.appendChild(omrQuestionElement);
                    }

                    showQuestion(currentQuestionIndex);
                    updateButtons();
                })
                .catch(error => console.error('Error fetching data:', error));

                document.getElementById("omr-form").addEventListener("submit", function(event) {
    event.preventDefault();
    
    // Collect form data
    const formData = new FormData(this);
    formData.append('testid', testid); // Add testid to the form data

    // Log form data for debugging
    for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
    }
    
    fetch('adminquiz.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log(data); 
        alert("Submitted successfully!"); // Show success alert
        $('#successModal').modal('show');
    })
    .catch(error => {
        console.error('Error:', error); 
    });
});

        };
    </script>
   
</body>
</html>