<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "omrsheet";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$testid = $_GET['testid'];  // Get testid from the query parameter
$userid = $_GET['userid'];  // Get userid from the query parameter

$sql = "SELECT score, correct_count, wrong_count FROM scores WHERE testid = ? AND userid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $testid, $userid);
$stmt->execute();
$stmt->bind_result($score, $correct_count, $wrong_count);
$stmt->fetch();

$response = [
    'score' => $score,
    'correct_count' => $correct_count,
    'wrong_count' => $wrong_count,
];

echo json_encode($response);

$stmt->close();
$conn->close();
?>
