<?php include 'userheader.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Landing Page</title>
    <style>
        h1{
            margin-top: 60PX;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .start-quiz-btn {
                padding: 5px 10px;
                border: none;
                background-color: #e118c6;
                color: white;
                cursor: pointer;
                border-radius: 5px;
            }
            .start-quiz-btn:hover {
                background-color: #e41dcd;
            }
    </style>
</head>
<body>
    <center><h1>TESTS</h1></center>
    <table id="testTable">
        <thead>
            <tr>
                <th>Test ID</th>
                <th>Test Name</th>
                <th>Time (Hr:Min:Sec)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="testGrid"></tbody>
    </table>

    <script>
        // Function to get URL parameters
        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        // Get the userid from the URL
        const userid = getUrlParameter('userid');

        // Fetch data from fetch_tests.php
        fetch('fetch_tests.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Fetched data:', data); // Debugging: log fetched data
                const grid = document.getElementById('testGrid');
                grid.innerHTML = ''; // Clear existing content

                data.forEach(test => {
                    // Create a new row for each test
                    const row = document.createElement('tr');

                    // Create cells for Test ID, Test Name, Time, and Action
                    const idCell = document.createElement('td');
                    idCell.textContent = test.testid;
                    row.appendChild(idCell);

                    const nameCell = document.createElement('td');
                    nameCell.textContent = test.testname;
                    row.appendChild(nameCell);

                    const timeCell = document.createElement('td');
                    timeCell.textContent = `${test.hours}:${test.minutes}:${test.seconds}`;
                    row.appendChild(timeCell);

                    const actionCell = document.createElement('td');
                    const startButton = document.createElement('button');
                    startButton.textContent = 'Start Quiz';
                    startButton.className = 'start-quiz-btn';
                    startButton.onclick = () => startQuiz(test.testid, userid); // Pass userid to the function
                    actionCell.appendChild(startButton);
                    row.appendChild(actionCell);

                    // Append the row to the table body
                    grid.appendChild(row);
                });
            })
            .catch(error => console.error('Error fetching tests:', error));

        // Function to handle Start Quiz button click
        function startQuiz(testid, userid) {
            // Redirect to right12.html with testid and userid as query parameters
            window.location.href = `quizheader.php?testid=${testid}&userid=${userid}`;
        }
       

    </script>
</body>
</html>
