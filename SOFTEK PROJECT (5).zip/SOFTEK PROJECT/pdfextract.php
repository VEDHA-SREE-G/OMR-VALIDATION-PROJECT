<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <style>
        .header {
            display: flex;
            justify-content: flex-end; /* Align items to the right */
            align-items: center;
            background-color: #c71585;
            color: #ffffff;
            padding: 10px 20px;
            width: 100%; /* Ensure header spans the full width */
            box-sizing: border-box; /* Include padding in width calculation */
            position: fixed; /* Fix the header at the top */
            top: 0;
            left: 0;
            z-index: 1000; /* Ensure it stays on top */
            height: 60px;
        }

        .header-content {
    display: flex;
    align-items: center;
    justify-content: space-between; /* Distribute space between items */
    width: 100%;
}

.menu-icon {
    font-size: 24px;
    cursor: pointer;
    margin-right: auto; /* Pushes the toggle button to the left */
    margin-left: 0; /* Ensure no left margin */
}


        .email {
            margin-right: 20px; /* Space between email and sign-out button */
            font-size: 16px;
            font-family: Arial, sans-serif;
        }

        .signout-button {
            background-color: #ffffff;
            color: #c71585;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
        }

        .signout-button:hover {
            background-color: #f5f5f5;
        }
        .dropdown {
            display: none;
            position: absolute;
            top: 40px; /* Positioned below the menu icon */
            left: 0;
            background-color: #ffffff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            overflow: hidden;
        }
        .dropdown a {
            display: block;
            padding: 10px 20px;
            color: #c71585;
            text-decoration: none;
            font-weight: 600;
        }
        .dropdown a:hover {
            background-color: #f5f5f5;
        }
        .show {
            display: block;
        }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .container {
            height: 100vh;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }
        .card {
            position: relative;
            border-radius: 10px;
            box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.3);
            width: 600px;
            height: 320px;
            background-color: #ffffff;
            padding: 10px 30px 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .card h3 {
            font-size: 22px;
            font-weight: 600;
        }
        .drop_box {
            margin: 10px 0;
            padding: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            border: 3px dotted #a3a3a3;
            border-radius: 5px;
        }
        .drop_box h4 {
            font-size: 16px;
            font-weight: 400;
            color: #2e2e2e;
        }
        .drop_box p {
            margin-top: 10px;
            margin-bottom: 20px;
            font-size: 12px;
            color: #a3a3a3;
        }
        .btn {
            text-decoration: none;
            background-color: #8806ce;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            outline: none;
            transition: 0.3s;
            cursor: pointer;
        }
        .btn:hover {
            text-decoration: none;
            background-color: #ffffff;
            color: #8806ce;
            padding: 10px 20px;
            border: none;
            outline: 1px solid #010101;
        }
        .form input {
            margin: 10px 0;
            width: 100%;
            background-color: #e2e2e2;
            border: none;
            outline: none;
            padding: 12px 20px;
            border-radius: 4px;
        }
        .bottom-btn {
            text-align: center;
            margin-top: 10px;
        }
        .bottom-btn a {
            text-decoration: none;
            background-color: #c71585;
            color: #ffffff;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }
        .bottom-btn a.disabled {
            background-color: #e2e2e2;
            color: #a3a3a3;
            cursor: not-allowed;
            pointer-events: none;
        }
        .bottom-btn a:hover {
            background-color: #a3006f;
        }
        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 24px;
            height: 24px;
            background-color: #c71585;
            color: #ffffff;
            text-align: center;
            line-height: 24px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        .close-btn:hover {
            background-color: #a3006f;
        }
        .question {
            margin-bottom: 20px;
        }
        .question.active {
            background-color: #f0f0f0;
        }
        .answer {
            font-weight: bold;
        }
        .answers .option {
            margin-bottom: 5px;
        }
        .omr-question {
            margin-bottom: 20px;
        }
        .omr-question .options-container {
            display: flex;
            flex-direction: column;
        }
        .omr-question .options-container .option {
            margin-bottom: 5px;
        }
        .omr-question .options-container input[type="radio"] {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
        <div class="menu-icon" onclick="toggleDropdown()">☰</div>
        <div class="dropdown" id="menuDropdown">
            <a href="adminlandingpg.php">Home</a>
            <a href="logout.php">Sign Out</a>
        </div>
            <div class="email">
                <?php
                // Display email based on user role
                if (isset($_SESSION['email'])) {
                    echo htmlspecialchars($_SESSION['email']);
                } else {
                    echo 'Not logged in';
                }
                ?>
            </div>
            <a href="logout.php" class="signout-button">Sign Out</a>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <div class="close-btn" onclick="goToLandingPage()">×</div>
            <h3>PDF Text Extractor</h3>
            <div class="drop_box">
                <h4>Drag and drop your file here or</h4>
                <p>Click the button below to upload your file</p>
                <form id="form" class="form" method="post" enctype="multipart/form-data">
                    <input type="file" id="fileElem" multiple accept="image/*,application/pdf" style="display:none" onchange="handleFiles(this.files)">
                    <label for="fileElem" class="btn">Upload</label>
                </form>
            </div>
            <div id="result" class="form"></div>
            <div class="bottom-btn">
                <a id="testDetailsBtn" class="disabled" onclick="openTestDetails()">Test Details</a>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.15.349/pdf.min.js"></script>
    <script>
        function toggleDropdown() {
            document.getElementById('menuDropdown').classList.toggle('show');
        }

        window.onclick = function(event) {
            if (!event.target.matches('.menu-icon')) {
                const dropdowns = document.getElementsByClassName("dropdown");
                for (let i = 0; i < dropdowns.length; i++) {
                    let openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }

        
        
        let pdfExtracted = false; // Flag to track if PDF content has been extracted
        let currentPdfId = null; // Variable to store the current PDF ID

        function handleFiles(files) {
            const file = files[0];
            const reader = new FileReader();
            reader.onload = function (e) {
                const typedarray = new Uint8Array(this.result);
                displayPdf(typedarray);
            };
            reader.readAsArrayBuffer(file);
        }

        function displayPdf(typedarray) {
            const pdf = new pdfjsLib.getDocument(typedarray);
            pdf.promise.then(pdf => {
                const maxPages = pdf._pdfInfo.numPages;
                let text = '';
                let pagePromises = [];

                for (let j = 1; j <= maxPages; j++) {
                    pagePromises.push(
                        pdf.getPage(j).then(page => {
                            return page.getTextContent().then(content => {
                                const strings = content.items.map(item => item.str);
                                text += strings.join('');
                            });
                        })
                    );
                }

                Promise.all(pagePromises).then(() => {
                    // Send the extracted text to PHP script for storing
                    fetch('store_pdf.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ pdfText: text })
                    }).then(response => response.text())
                      .then(data => {
                          console.log(data); // Log the response from the PHP script
                          const pdfId = parseInt(data, 10); // Parse the returned ID
                          if (pdfId) {
                              pdfExtracted = true; // Update flag after extraction
                              currentPdfId = pdfId; // Store the PDF ID
                              updateTestDetailsButton(); // Update button state
                          }
                      });
                });
            });
        }

        function updateTestDetailsButton() {
            const testDetailsBtn = document.getElementById('testDetailsBtn');
            if (pdfExtracted && currentPdfId) {
                testDetailsBtn.classList.remove('disabled');
                testDetailsBtn.onclick = function() { openTestDetails(); }; // Use the stored PDF ID
            } else {
                testDetailsBtn.classList.add('disabled');
                testDetailsBtn.onclick = null; // Disable button
            }
        }

        function openTestDetails() {
            if (pdfExtracted && currentPdfId) {
                window.open('testdetails.php?pdfId=' + currentPdfId, '_blank'); // Pass PDF ID as a query parameter
            }
        }

        function goToLandingPage() {
            window.location.href = 'adminlandingpg.php';
        }
    </script>
</body>
</html>
