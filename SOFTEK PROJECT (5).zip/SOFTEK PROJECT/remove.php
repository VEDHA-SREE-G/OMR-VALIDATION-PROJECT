<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Landing Page</title>
    <style>
        h1{
            margin-top: 80px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 40px; /* Add space for the fixed header */
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .remove-quiz-btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            background-color: #e912bb;
            color: white;
            margin-left: 10px;
        }
        .remove-quiz-btn:hover {
            background-color: #e21697;
        }
    </style>
</head>
<body>
    <center><h1>TESTS</h1></center>
    <table id="testTable">
        <thead>
            <tr>
                <th>Test ID</th>
                <th>Test Name</th>
                <th>Time (Hr:Min:Sec)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="testGrid"></tbody>
    </table>

    <script>
        // Fetch the user's email

        // Fetch data from fetch_tests.php
        fetch('fetch_tests.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const grid = document.getElementById('testGrid');
                grid.innerHTML = '';

                data.forEach(test => {
                    const row = document.createElement('tr');

                    const idCell = document.createElement('td');
                    idCell.textContent = test.testid;
                    row.appendChild(idCell);

                    const nameCell = document.createElement('td');
                    nameCell.textContent = test.testname;
                    row.appendChild(nameCell);

                    const timeCell = document.createElement('td');
                    timeCell.textContent = `${test.hours}:${test.minutes}:${test.seconds}`;
                    row.appendChild(timeCell);

                    const actionCell = document.createElement('td');
                    const removeButton = document.createElement('button');
                    removeButton.textContent = 'Remove Quiz';
                    removeButton.className = 'remove-quiz-btn';

                    // Attach event listener to remove the row
                    removeButton.onclick = () => removeQuiz(test.testid, row);
                    actionCell.appendChild(removeButton);

                    row.appendChild(actionCell);
                    grid.appendChild(row);
                });
            })
            .catch(error => console.error('Error fetching tests:', error));

        // Function to handle Remove Quiz button click
        function removeQuiz(testid, row) {
            if (confirm('Are you sure you want to remove this quiz?')) {
                fetch(`removequiz.php?testid=${testid}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        // Remove the row from the table
                        row.remove();
                    })
                    .catch(error => console.error('Error removing quiz:', error));
            }
        }
    </script>
</body>
</html>