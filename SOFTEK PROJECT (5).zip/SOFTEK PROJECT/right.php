<?php include 'quizheader.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" crossorigin="anonymous">
    <style>
        .container {
            display: flex;
            height: 100vh; /* 100% of the viewport height */
        }
        .questions-container {
            flex: 1;
            background-color: #f0f0f0;
            padding: 20px;
            overflow-y: auto; /* Scroll if content overflows */
            margin-top: 60px;
        }
        .omr-container {
            flex: 1;
            background-color: #e0e0e0;
            padding: 20px;
            overflow-y: auto;
            margin-top: 60px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            padding: 10px;
            background-color: #f0f0f0;
        }
        .navbar i {
            font-size: 24px;
            color: #333;
            cursor: pointer;
        }
        .circle-button {
            display: inline-block;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #c71585;
            text-align: center;
            font-size: 16px;
            margin-right: 10px;
            transition: background-color 0.3s;
        }
        .circle-button:hover {
            background-color: #8806ce;
        }
        .btn {
            background-color: #c71585;
        }
        .btn:hover {
            background-color: #8806ce;
        }
        .omr-question {
            margin-bottom: 20px;
        }
        .options-container {
            margin-top: 10px;
        }
        .option {
            margin-bottom: 5px;
        }
        .omr-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .omr-row label {
            margin-right: 10px;
        }
        .omr-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 2px solid #000;
            display: inline-block;
            text-align: center;
            line-height: 26px; /* Vertically center the text */
            font-weight: bold;
            margin-right: 10px;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s, border-color 0.3s;
            position: relative;
        }

        .omr-circle input[type="radio"] {
            display: none;
        }
    

        .omr-circle input[type="radio"]:checked + span {
            background-color: #000; /* Fully black circle */
            color: #000; /* White text color */
            border-color: #000; /* Change the border color to match the background */
            display: inline-block; /* Ensure the span acts as a block to cover the circle */
            width: 100%; /* Make sure the span covers the whole circle */
            height: 100%; /* Full height to match the circle */
            border-radius: 50%; /* Maintain the circle shape */
            line-height: 26px; /* Center the text vertically */
        }
        .question-number {
            width: 50px;
            text-align: right;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="questions-container">
            <h1 id="testName">Test Name</h1>
            <div id="questionDisplay">Loading question...</div>
            <div class="options-container" id="optionsDisplay"></div>
            <div class="btn-group">
                <button id="prevBtn" class="btn" onclick="prevQuestion()">Previous</button>
                <button id="nextBtn" class="btn" onclick="nextQuestion()">Next</button>
            </div>
        </div>
        <div class="omr-container">
            <form id="omr-form" method="post" action="userquiz.php">
            <h2>OMR SHEET</h2>
            <div id="omrOptions">Loading OMR options...</div>
            <button id="download" type="button" class="btn">
                <svg width="24px" height="24px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mysvg">
                    <g id="SVGRepo_iconCarrier">
                        <path id="Vector" d="M6 21H18M12 3V17M12 17L17 12M12 17L7 12" stroke="#f1f1f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </g>
                </svg>
                <span class="texto">Download</span>
            </button>
            <input type="submit" value="Submit" id="submit" class="btn">
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        let currentQuestionIndex = 0;
        let questionsData = [];
        let countdownInterval;

    
        // Fetch testid from URL query parameters
        const urlParams = new URLSearchParams(window.location.search);
        const testid = urlParams.get('testid');
        const userid = urlParams.get('userid');
    
    
        function startCountdown(totalSeconds) {
            const updateDisplay = () => {
                const hours = Math.floor(totalSeconds / 3600);
                const minutes = Math.floor((totalSeconds % 3600) / 60);
                const seconds = totalSeconds % 60;
                document.getElementById('testTime').textContent = `${hours}h ${minutes}m ${seconds}s`;
    
                if (totalSeconds <= 0) {
                    clearInterval(countdownInterval);
                    alert("Time's up!");
                    // Optionally, disable further actions or auto-submit the quiz here
                    document.getElementById('submit').click();
                }
    
                totalSeconds--;
            };
    
            updateDisplay(); // Initial display
            countdownInterval = setInterval(updateDisplay, 1000); // Update every second
        }
    
        fetch(`right12.php?testid=${testid}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('testName').textContent = data.test.testname;
                questionsData = data.pdf_content.split('Q').slice(1);
                loadQuestion(currentQuestionIndex);
                loadOMR();
            })
            .catch(error => {
                console.error('Error fetching content:', error);
                document.getElementById('questionDisplay').textContent = 'Error loading content.';
                document.getElementById('omrOptions').textContent = 'Error loading OMR options.';
            });
    
        function loadQuestion(index) {
            const questionDisplay = document.getElementById('questionDisplay');
            const optionsDisplay = document.getElementById('optionsDisplay');
            questionDisplay.innerHTML = '';
            optionsDisplay.innerHTML = '';
    
            const questionData = questionsData[index];
            const [questionText, ...answers] = questionData.split(/(?=[ABCD]\d+\.)/);
            const cleanQuestion = questionText.trim();
            const cleanAnswers = answers.map(answer => answer.trim());
    
            const questionElement = document.createElement('div');
            questionElement.innerHTML = `<h3>Q${index + 1}:</h3><p>${cleanQuestion}</p>`;
            questionDisplay.appendChild(questionElement);
    
            cleanAnswers.forEach(answer => {
                const optionElement = document.createElement('div');
                optionElement.className = 'option';
                optionElement.textContent = answer;
                optionsDisplay.appendChild(optionElement);
            });
    
            document.getElementById('prevBtn').style.display = index === 0 ? 'none' : 'inline-block';
            document.getElementById('nextBtn').style.display = index === questionsData.length - 1 ? 'none' : 'inline-block';
        }
    
        function loadOMR() {
            const omrOptions = document.getElementById('omrOptions');
            omrOptions.innerHTML = '';
            questionsData.forEach((_, index) => {
                const omrRow = document.createElement('div');
                omrRow.className = 'omr-row';
                omrRow.innerHTML = `
                    <span class="question-number">Q${index + 1}</span>
                    <label class="omr-circle">
                        <input type="radio" id="q${index + 1}a" name="q${index + 1}" value="A">
                        <span>A</span>
                    </label>
                    <label class="omr-circle">
                        <input type="radio" id="q${index + 1}b" name="q${index + 1}" value="B">
                        <span>B</span>
                    </label>
                    <label class="omr-circle">
                        <input type="radio" id="q${index + 1}c" name="q${index + 1}" value="C">
                        <span>C</span>
                    </label>
                    <label class="omr-circle">
                        <input type="radio" id="q${index + 1}d" name="q${index + 1}" value="D">
                        <span>D</span>
                    </label>
                `;
                omrOptions.appendChild(omrRow);
            });
        }
    
        function prevQuestion() {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                loadQuestion(currentQuestionIndex);
            }
        }
    
        function nextQuestion() {
            if (currentQuestionIndex < questionsData.length - 1) {
                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            }
        }
    
        function submitAnswers() {
            const element = document.getElementById('omrOptions');
            const opt = {
                margin: 1,
                filename: 'omr_sheet.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
    
            html2pdf().from(element).set(opt).save();
        }
        document.getElementById("omr-form").addEventListener("submit", function(event) {
                event.preventDefault();
                
                // Collect form data
                const formData = new FormData(this);
                formData.append('testid', testid); // Add testid to the form data
                formData.append('userid', userid);
                fetch('userquiz.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    console.log(data); 
                    $('#successModal').modal('show');
                })
                .catch(error => {
                    console.error('Error:', error); 
                });
                window.location.href = `result.php?testid=${testid}&userid=${userid}`; 
            });

        window.onload = function () {
            document.getElementById("download").addEventListener("click", submitAnswers);
        };
    </script>
    
</body>
</html>