<?php include 'userheader.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
        }

        h1 {
            color: #333;
        }

        .result {
            margin-top: 20px;
        }

        .score {
            font-size: 2em; /* Larger font size */
            font-weight: bold; /* Bold text */
            color: #555;
        }

        button {
            background-color: #4B0082;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 20px;
            margin: 10px;
            cursor: pointer;
            font-size: 1em;
        }

        button:hover {
            background-color: #0056b3;
        }

        .chart-container {
            display: flex;
            justify-content: center; /* Center the pie chart */
            margin-top: 20px;
        }

        canvas {
            max-width: 300px; /* Adjust size of pie chart */
            max-height: 300px; /* Adjust size of pie chart */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Quiz Result</h1>
        <div class="result">
            <p class="score">Congratulations! You scored <br><span id="score">85</span> out of <span id="total">100</span>.</p>
            <div class="chart-container">
                <canvas id="pieChart" width="300" height="300"></canvas>
            </div>
            <button onclick="retryQuiz()">BACK TO HOME-></button>
        </div>
    </div>

    <!-- Include Chart.js and Chart.js Data Labels Plugin -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <script>
    function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        // Get the userid from the URL
        const testid = getUrlParameter('testid')
        const userid = getUrlParameter('userid');
        fetch(`get_score.php?testid=${testid}&userid=${userid}`)
    .then(response => response.json())
    .then(data => {
        const correctAnswers = data.correct_count;
        const incorrectAnswers = data.wrong_count;
        const score = data.score;
        const totalQuestions = correctAnswers + incorrectAnswers;

        console.log("Correct Answers:", correctAnswers);
        console.log("Incorrect Answers:", incorrectAnswers);
        console.log("Score:", score);

        document.getElementById('score').innerText = score;
        document.getElementById('total').innerText = totalQuestions * 10;  // Assuming each question is worth 10 points

        const ctx = document.getElementById('pieChart').getContext('2d');

        // Ensure the canvas is correctly referenced
        if (ctx) {
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Correct Answers', 'Incorrect Answers'],
                    datasets: [{
                        data: [correctAnswers, incorrectAnswers],
                        backgroundColor: ['#28a745', '#dc3545'], // Green for correct, Red for incorrect
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        datalabels: {
                            color: '#fff',
                            formatter: (value, context) => {
                                const total = context.dataset.data.reduce((acc, val) => acc + val, 0);
                                const percentage = ((value / total) * 100).toFixed(2);
                                return `${percentage}%`;
                            },
                            anchor: 'center',
                            align: 'center',
                            font: {
                                weight: 'bold',
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    const label = tooltipItem.label || '';
                                    const value = tooltipItem.raw;
                                    return `${label}: ${value} (${((value / totalQuestions) * 100).toFixed(2)}%)`;
                                }
                            }
                        }
                    }
                }
            });
        } else {
            console.error("Canvas context could not be retrieved.");
        }
    })
    .catch(error => console.error('Error fetching data:', error));
            function retryQuiz() {
            // Redirect to quiz page or reload the quiz
            window.location.href = `userlandingpg.php?userid=${userid}`; // Change to your quiz page
        }
    </script>
    
</body>
</html>